package com.puyodev.consumoapi.data;

public class PostViewModel {
}
